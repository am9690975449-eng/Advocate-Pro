# Advocate Pro — Android starter project

A bilingual (English/Hindi), offline-capable legal workspace prototype.

## Included working modules
- Home dashboard and 18 Indian-law domain directories
- Searchable starter section reference and indicative old/new-law mapping
- Drafting studio with editable starter templates
- Local case register (stored only in this device/browser storage)
- Legal research links to India Code, Supreme Court, Allahabad High Court, eCourts and NCRB
- Basic date interval calculator
- English/Hindi interface toggle
- PWA manifest and service worker for browser installation/offline shell
- Android Studio WebView wrapper project

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`AdvocatePro_Android`) in Android Studio.
3. Allow Gradle sync; use JDK 17 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK output location (normally `app/build/outputs/apk/debug/app-debug.apk`).

This is a source project, not a signed/release APK. A release APK requires your own signing key and a release build configuration.

## Install as a PWA without Android Studio
Host the contents of `app/src/main/assets/www/` on an HTTPS website, open it in Chrome on Android, then choose the browser menu > Install app / Add to Home screen.

## Important legal/content limits
This is a functional starter app and navigation/workspace prototype, not a complete authoritative Indian law database. The section library contains a small illustrative set of commonly used provisions; mappings are indicative, not exhaustive. The app does not currently fetch live judgments, perform AI legal research, sync cases to cloud, or verify amendments automatically. Use official linked sources and check the current bare Act, rules, schedules, notifications and binding precedent before court use.

## Privacy
Case entries and research notes are stored in local browser/WebView storage on the device. Do not use on a shared device for confidential client material. No cloud sync or encryption layer is included in this starter build.
